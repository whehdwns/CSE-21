package pig;

public class ConservativePlayer extends Player {

 
	
}
